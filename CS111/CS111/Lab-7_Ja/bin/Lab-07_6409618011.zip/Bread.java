//Kanyanat Det-in
//6409618011
public class Bread {
	public static String SOFT="Soft";
	public static String BURNT="Burnt";
	public static String CRISP="Crisp";
	private String state;
	public Bread() {
	}
	public String getState() {
		return state;
	}
	public void setState(String level) {
		state=level;
	}
}
