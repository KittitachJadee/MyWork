//Kanyanat Det-in
//6409618011
public class ToasterTest {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Toaster machine=new Toaster();
		Bread bread=new Bread();
		machine.toast(bread);
	}
}