//Pangon La-or-on
//6409700074

public class Bread {
	public static String SOFT="Soft";
	public static String BURNT="Burnt";
	public static String CRISP="Crisp";
	private String state;
	
	public Bread() {
	}
	
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state=state;
	}
}
