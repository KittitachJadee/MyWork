//Pangon La-or-on
//6409700074

public class ToasterTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Toaster toaster=new Toaster();
		Bread bread=new Bread();
		toaster.toast(bread);
	}
}